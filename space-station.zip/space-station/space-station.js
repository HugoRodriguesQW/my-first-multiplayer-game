export default function spaceStationEngine(ctx) {

  let modulesLoaded = 0
  const stations = []

  const stationParts = {
    'c-module': getStationModule('center'),
    'srv-module': getStationModule('capsule'),
    'slr-panels': getStationModule('solar'),
    'connector': getStationModule('connector')
  }


  function getStationModule(name) {

    const img = new Image()
    img.src = "" + `modules/${name}.png`

    img.onload = function() {
      modulesLoaded++
    }

    return img
  }

  function generateStation(position) {
    const station = []

    const center = addModule('c-module', true)
    center.pos = position
    station.push(center)

    function makeConnector() {
      const module = new Image(
        stationParts['connector'].width,
        stationParts['connector'].height
      )

      module.src = stationParts['connector'].src
      module.type = 'connector'

      const parent = station[station.length - 1]
      module.pos = {
        x: parent.pos.x + parent.width,
        y: parent.pos.y + parent.height / 2 - (module.height / 2)
      }
      station.push(module)
    }

    function addModule(type, isCenter) {

      //Creates a blank image at the size of the true image.
      const module = new Image(
        stationParts[type].width,
        stationParts[type].height
      )

      module.src = stationParts[type].src
      module.type = type


      if (!isCenter) { //Add a 'Connector' and then add the module.
        makeConnector()

        const parent = station[station.length - 1]
        module.pos = {
          x: parent.pos.x + parent.width,
          y: parent.pos.y + parent.height / 2 - (module.height / 2)
        }
        station.push(module)
      }

      return module
    }

    // Call
    addModule('c-module')
    addModule('srv-module')
    addModule('slr-panels')


    return station
  }


  function update() {
    ctx.clearRect(0, 0, 1000, 1000)
    for (const stt in stations) {
      const station = stations[stt]

      for (const module in station) {
        const mod = station[module]
        if (mod != undefined) {
          ctx.drawImage(mod, mod.pos.x, mod.pos.y, mod.width, mod.height)
        }
      }
    }


  }

  function init() {

    if (modulesLoaded === Object.keys(stationParts).length) {
      const myStation = generateStation({ x: 200, y: 200 })

      stations.push(myStation)
      setInterval(update, 1000 / 30)
    }

    else {
      setTimeout(() => {
        init()
      }, 100)
    }
  }


  init()
}
